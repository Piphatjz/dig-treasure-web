@echo off
agy --model claude-sonnet-4-6 --mode accept-edits --dangerously-skip-permissions %*